package com.test.android_memohomework.category_memo

class TotalData {
    companion object{
        var categoryMap = LinkedHashMap<String, ArrayList<Memo>>()
    }

}

