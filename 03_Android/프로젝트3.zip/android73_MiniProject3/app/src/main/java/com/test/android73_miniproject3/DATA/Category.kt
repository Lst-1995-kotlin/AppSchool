package com.test.android73_miniproject3.DATA

data class Category(var name: String, var updateTime: Long)
