package com.test.android73_miniproject3.DATA

data class Memo(var category: String, var memoTitle: String, var memoContents: String, var updateTime: Long)
