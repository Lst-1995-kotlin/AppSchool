class StudentManager {

    // 점수를 입력받는다.
    fun inputPoint(){

    }

    // 점수를 출력한다.
    fun printPoint(){

    }

    // 과목별 총점과 평균을 출력한다.
    fun printAgg(){

    }
}