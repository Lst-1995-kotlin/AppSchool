import java.util.Scanner
import kotlin.math.roundToInt

//1. 어떠한 클래스들이 필요한지를 정리한다(한국어 주석)
//2. 각 클래스들의 이름을 정의한다(class 클래스명)
//3. 각 클래스가 가져야할 모든 변수와 모든 메서드들을 클래스 내부에 정의한다(한국어 주석)
//4. 한국어 주석으로 작성한 모든 변수와 모든 메서드들을 작성한다(멤버변수, 메서드는 { } 까지만)
//5. 각 클래스 별로 중복되는 요소들을 정리한다.
//6. 중복되는 요소들을 가지는 부모 클래스들을 정의한다.
//7. 정의된 부모 클래스들 중에 메서드로만 구성되는 것은 인터페이스로 변경한다.
//8. 부모 클래스들이 상속 받거나 구현해야 하는 인터페이스들을 설정해준다.
//8-1. 만약 자식 클래스가 구현해야 하는 메서드가 있다면 추상 메서드로 정의하고 클래스는 추상 클래스로 정의한다.
//9. 최종 자식 클래스에 상속과 인터페이스를 설정해준다.
//10. 최종 자식 클래스의 메서드들을 구현해준다.

fun main(){

    val student = School()

    student.stdInput()
    student.printStdInfo()

    student.go()
    student.totalStdCountInfo()

}

enum class Type(val afl: String, val aflNum: Int){

    SOCCER("축구",1),
    VLYBL("배구",2),
    SWIM("수영",3),
    NOMAL("일반",4)
}

// 학교클래스
class School:ClassRoom,PlayGround,Gym,SwimmingPool{
    // 학생을 저장할 리스트
    val stdList = ArrayList<BasicStd>()
    // 각 소속인원 체크
    var soccerClubCount = 0
    var vlyblClubCount = 0
    var swimClubCount = 0

    // 학생의 정보를 입력받는 기능
    fun stdInput(){
        val scan = Scanner(System.`in`)
        var num = 0
        while(true){
            print("학생의 소속을 정해주십시오 : 1.축구, 2.배구, 3.수영, 4.일반, 0.종료 : ")
            var num = scan.nextInt()

            if(num !in 0 .. 4){
                println("잘못입력하였습니다 다시 입력하십시오")
                continue
            }
            if(num == 0){
                println()
                break
            }

            print("학생의 이름을 알려주십시오 : ")
            val name = scan.next()
            print("학생의 학년을 알려주십시오 : ")
            val grade = scan.nextInt()
            print("학생의 국어 점수를 알려주십시오 : ")
            val kor = scan.nextInt()
            print("학생의 영어 점수를 알려주십시오 : ")
            val eng = scan.nextInt()
            print("학생의 수학 점수를 알려주십시오 : ")
            val math = scan.nextInt()
            println("-----------------------------------")

            when(num){
                Type.SOCCER.aflNum ->{ // 축구 공부를 한다, 축구를 한다, 수영을 한다.
                    val std = object : BasicStd(Type.SOCCER.afl,name,grade,kor,eng,math),
                        PlaySoccer,PlaySwim{
                        override fun playStudy() {
                            println("$name 학생이 교실에서 공부하고 있습니다")
                        }

                        override fun playSoccer() {
                            println("$name 학생이 운동장에서 축구를 하고 있습니다")
                        }

                        override fun playSwim() {
                            println("$name 학생이 수영장에서 수영을 하고 있습니다")
                        }
                    }
                    stdList.add(std)
                    soccerClubCount++
                }
                Type.SWIM.aflNum ->{ // 수영 공부를 한다, 배구를 한다, 수영를 한다.
                    val std = object : BasicStd(Type.SWIM.afl,name,grade,kor,eng,math),
                        PlayVlybl,PlaySwim{
                        override fun playStudy() {
                            println("$name 학생이 교실에서 공부하고 있습니다")
                        }

                        override fun playSwim() {
                            println("$name 학생이 수영장에서 수영을 하고 있습니다")
                        }

                        override fun playVlybl() {
                            println("$name 학생이 체육관에서 배구를 하고 있습니다")
                        }
                    }
                    stdList.add(std)
                    swimClubCount++

                }
                Type.VLYBL.aflNum ->{ // 배구
                    val std = object : BasicStd(Type.VLYBL.afl,name,grade,kor,eng,math),
                        PlayVlybl,PlaySoccer{
                        override fun playStudy() {
                            println("$name 학생이 교실에서 공부하고 있습니다")
                        }

                        override fun playSoccer() {
                            println("$name 학생이 운동장에서 축구를 하고 있습니다")
                        }

                        override fun playVlybl() {
                            println("$name 학생이 체육관에서 배구를 하고 있습니다")
                        }
                    }
                    stdList.add(std)
                    vlyblClubCount++
                }

                Type.NOMAL.aflNum ->{
                    val std = object : BasicStd(Type.NOMAL.afl,name,grade,kor,eng,math){
                        override fun playStudy() {
                            println("$name 학생이 교실에서 공부하고 있습니다")
                        }
                    }
                    stdList.add(std)
                }
            }
        }
    }

    var playSoccerCount = 0
    var playVlyblCount = 0
    var playSwimCount = 0

    // 학생의 정보들을 출력하는 기능
    fun printStdInfo(){
        for(std in stdList){
            std.printInfo()
            println()
        }
    }
    // 한번에 모두 보내버리기
    fun go(){
        // 교실 보내기
        goClassRoom()
        println()
        // 운동장 보내기
        goPlayGround()
        println()
        // 체육관 보내기
        goGym()
        println()
        // 수영장 보내기
        goSwimmingPool()
        println()
    }

    // 학생들을 교실에 보내는 기능
    override fun goClassRoom() {
        for(std in stdList){
            if(std is PlayStudy){
                std.playStudy()
            }
        }

    }
    // 학생들을 운동장에 보내는 기능
    override fun goPlayGround() {
        for(std in stdList){
            if(std is PlaySoccer){
                std.playSoccer()
                playSoccerCount++
            }
        }
    }
    // 학생들을 체육관으로 보내는 기능
    override fun goGym() {
        for (std in stdList){
            if(std is PlayVlybl){
                std.playVlybl()
                playVlyblCount++
            }
        }
    }
    // 학생들을 수영장으로 보내는 기능
    override fun goSwimmingPool() {
        for(std in stdList){
            if(std is PlaySwim){
                std.playSwim()
                playSwimCount++
            }
        }
    }

    // 현재 학생수를 기반으로 정보를 출력하는 기능
//    전체 학생 수 : 000명
//    일반 학생 수  : 000명
//    축구부 학생 수 : 000명
//    배구부 학생 수 : 000명
//    수영부 학생 수 :000명
//    축구를 하는 학생 수 : 000명
//    배구를 하는 학생 수 : 000명
//    수영을 하는 학생 수 : 000명
    fun totalStdCountInfo(){
        val total = stdList.size
        val nomal = total - soccerClubCount - vlyblClubCount - swimClubCount

        println("전체 학생 수 : ${total}명")
        println("일반 학생 수  : ${nomal}명")
        println("축구부 학생 수 : ${soccerClubCount}명")
        println("배구부 학생 수 : ${vlyblClubCount}명")
        println("수영부 학생 수 : ${swimClubCount}명")
        println("축구를 하는 학생 수 : ${playSoccerCount}명")
        println("배구를 하는 학생 수 : ${playVlyblCount}명")
        println("수영을 하는 학생 수 : ${playSwimCount}명")


    }

}
// 교실 클래스
interface ClassRoom{
    // 들어온 학생들을 공부시키는 기능
    fun goClassRoom()
}
// 운동장 클래스
interface PlayGround{
    // 들어온 학생들 중 축구부와 배구부들을 축구시키는 기능
    fun goPlayGround()
}
// 체육관 클래스
interface Gym{
    // 들어온 학생들 중 배구부와 수영부 학생들을 배구시키는 기능
    fun goGym()
}
// 수영장 클래스
interface SwimmingPool{
    // 들어온 학생들 중 수영부와 축구부 학생들을 수영시키는 기능
    fun goSwimmingPool()
}



// 일반 학생 클래스(부모클래스예정)
open abstract class BasicStd(val afl: String, val name: String, val grade: Int,
               val kor: Int, val eng: Int, val math: Int):PlayStudy {

// 학생들의 정보를 출력하는 기능
    open fun printInfo(){
        println("소속 : ${afl}부")
        println("이름 : $name")
        println("학년 : ${grade}학년")
        println("국어 : ${kor}점")
        println("영어 : ${eng}점")
        println("수학 : ${math}점")
        println("개인 총점 : ${kor+eng+math}점")
        println("개인 평균 : ${((kor+eng+math)/3.0)}점")

    }

}
// 학생들이 공부하는 기능
interface PlayStudy{
    fun playStudy()
}

// 축구를 하는 클래스
interface PlaySoccer{
    // 축구를 하는 기능
    fun playSoccer()
}
// 배구를 하는 클래스
interface PlayVlybl{
    // 배구를 하는 기능
    fun playVlybl()
}
// 수영을 하는 클래스
interface PlaySwim{
    // 수영을 하는 기능
    fun playSwim()
}
